using System;
using System.Windows.Forms;
using Genysis_Admin_Tool;
using Microsoft.Extensions.Configuration;

namespace AdminTool
{
    static class Program
    {
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            // Konfiguration laden
            var configuration = new ConfigurationBuilder()
                .SetBasePath(AppContext.BaseDirectory)
                .AddJsonFile("dbconfig.json", optional: false, reloadOnChange: true)
                .Build();

            // Zeigen Sie das Login-Formular an
            using (var loginForm = new LoginForm(configuration))
            {
                if (loginForm.ShowDialog() == DialogResult.OK)
                {
                    // Wenn die Anmeldung erfolgreich ist, zeigen Sie Form1 an
                    Application.Run(new Form1(configuration));
                }
                else
                {
                    // Beenden Sie die Anwendung, wenn die Anmeldung fehlgeschlagen ist
                    Application.Exit();
                }
            }
        }
    }
}
