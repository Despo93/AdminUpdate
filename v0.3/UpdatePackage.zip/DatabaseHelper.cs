﻿using System;
using System.Data;
using MySql.Data.MySqlClient;

namespace AdminTool
{
    public class DatabaseHelper
    {
        private readonly string connectionString;

        public DatabaseHelper(string connectionString)
        {
            this.connectionString = connectionString;
        }

        public DataTable GetEventCoins(int userId)
        {
            var dataTable = new DataTable();

            try
            {
                using (var connection = new MySqlConnection(connectionString))
                {
                    var command = new MySqlCommand("SELECT * FROM event_coins WHERE userId = @userId", connection);
                    command.Parameters.Add("@userId", MySqlDbType.Int32).Value = userId;
                    var adapter = new MySqlDataAdapter(command);
                    adapter.Fill(dataTable);
                }
            }
            catch (Exception ex)
            {
                // Log error or handle it accordingly
                Console.WriteLine($"An error occurred in GetEventCoins: {ex.Message}");
            }

            return dataTable;
        }

        public DataTable GetPlayerData(int userId)
        {
            var dataTable = new DataTable();

            try
            {
                using (var connection = new MySqlConnection(connectionString))
                {
                    var command = new MySqlCommand("SELECT * FROM player_accounts WHERE userId = @userId", connection);
                    command.Parameters.Add("@userId", MySqlDbType.Int32).Value = userId;
                    var adapter = new MySqlDataAdapter(command);
                    adapter.Fill(dataTable);
                }
            }
            catch (Exception ex)
            {
                // Log error or handle it accordingly
                Console.WriteLine($"An error occurred in GetPlayerData: {ex.Message}");
            }

            return dataTable;
        }

        public DataTable GetPlayerEquip(int userId)
        {
            var dataTable = new DataTable();

            try
            {
                using (var connection = new MySqlConnection(connectionString))
                {
                    var command = new MySqlCommand("SELECT * FROM player_equipment WHERE userId = @userId", connection);
                    command.Parameters.Add("@userId", MySqlDbType.Int32).Value = userId;
                    var adapter = new MySqlDataAdapter(command);
                    adapter.Fill(dataTable);
                }
            }
            catch (Exception ex)
            {
                // Log error or handle it accordingly
                Console.WriteLine($"An error occurred in GetPlayerEquip: {ex.Message}");
            }

            return dataTable;
        }
        public bool SetEventCoins(int userId, int coins)
        {
            try
            {
                using (var connection = new MySqlConnection(connectionString))
                {
                    connection.Open();

                    // SQL-Befehl zur Aktualisierung der Coins für den bestimmten Benutzer
                    var command = new MySqlCommand(
                        "UPDATE event_coins SET coins = @coins WHERE userId = @userId", connection);

                    // Parameter hinzufügen
                    command.Parameters.Add("@coins", MySqlDbType.Int32).Value = coins;
                    command.Parameters.Add("@userId", MySqlDbType.Int32).Value = userId;

                    // Ausführen des Befehls
                    int rowsAffected = command.ExecuteNonQuery();

                    // Rückgabe true, wenn eine Zeile aktualisiert wurde, sonst false
                    return rowsAffected > 0;
                }
            }
            catch (Exception ex)
            {
                // Fehlerprotokollierung
                Console.WriteLine($"An error occurred in SetEventCoins: {ex.Message}");
                return false;
            }
        }
        public bool SetPlayerData(int userId, string username, string pilotName, string petName, string petDesign, string title, string factionId, string data, string bootyKeys, string info, string position)
        {
            try
            {
                using (var connection = new MySqlConnection(connectionString))
                {
                    connection.Open();
                    var command = new MySqlCommand(
                        "UPDATE player_accounts SET username = @username, pilotName = @pilotName, PetName = @petName, PetDesign = @petDesign, Title = @title, FactionId = @factionId, data = @data, bootyKeys = @bootyKeys, info = @info, position = @position WHERE userId = @userId",
                        connection);

                    command.Parameters.Add("@username", MySqlDbType.VarChar).Value = username;
                    command.Parameters.Add("@pilotName", MySqlDbType.VarChar).Value = pilotName;
                    command.Parameters.Add("@petName", MySqlDbType.VarChar).Value = petName;
                    command.Parameters.Add("@petDesign", MySqlDbType.VarChar).Value = petDesign;
                    command.Parameters.Add("@title", MySqlDbType.VarChar).Value = title;
                    command.Parameters.Add("@factionId", MySqlDbType.VarChar).Value = factionId;
                    command.Parameters.Add("@data", MySqlDbType.Text).Value = data;
                    command.Parameters.Add("@bootyKeys", MySqlDbType.Text).Value = bootyKeys;
                    command.Parameters.Add("@info", MySqlDbType.Text).Value = info;
                    command.Parameters.Add("@position", MySqlDbType.Text).Value = position;
                    command.Parameters.Add("@userId", MySqlDbType.Int32).Value = userId;

                    int rowsAffected = command.ExecuteNonQuery();
                    return rowsAffected > 0;
                }
            }
            catch (Exception ex)
            {
                // Log error or handle it accordingly
                Console.WriteLine($"An error occurred in SetPlayerData: {ex.Message}");
                return false;
            }
        }
        public bool SetPlayerEquip(int userId, string equipmentData)
        {
            try
            {
                using (var connection = new MySqlConnection(connectionString))
                {
                    connection.Open();
                    var command = new MySqlCommand(
                        "UPDATE player_equipment SET equipmentData = @equipmentData WHERE userId = @userId",
                        connection);

                    command.Parameters.Add("@equipmentData", MySqlDbType.Text).Value = equipmentData;
                    command.Parameters.Add("@userId", MySqlDbType.Int32).Value = userId;

                    int rowsAffected = command.ExecuteNonQuery();
                    return rowsAffected > 0;
                }
            }
            catch (Exception ex)
            {
                // Log error or handle it accordingly
                Console.WriteLine($"An error occurred in SetPlayerEquip: {ex.Message}");
                return false;
            }
        }

    }
}
