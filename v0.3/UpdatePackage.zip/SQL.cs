﻿using MySqlConnector;
using System;

namespace AdminTool
{
    public class SQL
    {
        private string _connectionString;

        public SQL(string connectionString)
        {
            _connectionString = connectionString;
        }

        public bool ValidateLogin(string username, string password)
        {
            using (var connection = new MySqlConnection(_connectionString))
            {
                try
                {
                    connection.Open();
                    var command = new MySqlCommand("SELECT password FROM player_accounts WHERE username = @username AND rankId = 21", connection);
                    command.Parameters.AddWithValue("@username", username);

                    var result = command.ExecuteScalar();
                    if (result != null)
                    {
                        string storedPasswordHash = result.ToString();
                        return BCrypt.Net.BCrypt.Verify(password, storedPasswordHash);
                    }
                }
                catch (Exception ex)
                {
                    // Handle exceptions as needed
                    Console.WriteLine(ex.Message);
                }
            }

            return false;
        }
    }
}
