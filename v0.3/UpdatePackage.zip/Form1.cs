using System;
using System.Collections.Generic;
using System.Windows.Forms;
using Microsoft.Extensions.Configuration;

namespace AdminTool
{
    public partial class Form1 : Form
    {
        private List<Panel> panels;
        private DatabaseHelper dbHelper;

        // Variablen f�r das Dragging
        private bool isDragging = false;
        private Point lastCursor;
        private Point lastForm;
        public int GetSearchUserId()
        {
            int userId;
            if (int.TryParse(textBoxIdSearch.Text, out userId))
            {
                return userId;
            }
            else
            {
                throw new InvalidOperationException("Invalid user ID.");
            }
        }

        public Form1(IConfiguration configuration)
        {
            InitializeComponent();

            panels = new List<Panel>
            {
                panelChildForm,
            };

            string connectionString = configuration.GetConnectionString("DefaultConnection");
            dbHelper = new DatabaseHelper(connectionString);

            // Event-Handler f�r das Dragging hinzuf�gen
            panelTileBar.MouseDown += panelTileBar_MouseDown;
            panelTileBar.MouseMove += panelTileBar_MouseMove;
            panelTileBar.MouseUp += panelTileBar_MouseUp;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
        }

        private void iconButtonAmmo_Click_1(object sender, EventArgs e)
        {
            openChildForm(new Ammo(dbHelper));
        }

        private void iconButtonDash_Click(object sender, EventArgs e)
        {
            // Die userId wird hier als Beispiel gesetzt
            int userId = 1; // Dies sollte durch den tats�chlichen Wert ersetzt werden
            openChildForm(new Dashboard(dbHelper, userId));
        }

        private void iconButtonGear_Click_1(object sender, EventArgs e)
        {
            openChildForm(new Gear(dbHelper));
        }

        private void iconButton4_Click_1(object sender, EventArgs e)
        {
            openChildForm(new Configs(dbHelper));
        }

        private void iconButton6_Click_1(object sender, EventArgs e)
        {
            openChildForm(new Gate(dbHelper));
        }

        private Form activeForm = null;

        private void openChildForm(Form childForm)
        {
            if (activeForm != null)
                activeForm.Close();
            activeForm = childForm;
            childForm.TopLevel = false;
            childForm.FormBorderStyle = FormBorderStyle.None;
            childForm.Dock = DockStyle.Fill;
            panelChildForm.Controls.Add(childForm);
            panelChildForm.Tag = childForm;
            childForm.BringToFront();
            childForm.Show();
        }

        private void buttonSave_Click(object sender, EventArgs e)
        {
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (activeForm != null)
            {
                int userId;
                if (int.TryParse(textBoxIdSearch.Text, out userId))
                {
                    if (activeForm is Ammo ammoForm)
                    {
                        ammoForm.UpdateTextBoxes();
                    }
                    else if (activeForm is Dashboard dashboardForm)
                    {
                        dashboardForm.UpdateTextBoxes(userId); // Pass the userId to the Dashboard form
                    }
                    else if (activeForm is Configs configsForm)
                    {
                        configsForm.UpdateTextBoxes();
                    }
                    else if (activeForm is Gate gateForm)
                    {
                        gateForm.UpdateTextBoxes();
                    }
                    else if (activeForm is Gear gearForm)
                    {
                        gearForm.UpdateTextBoxes();
                    }
                }
                else
                {
                    MessageBox.Show("Please enter a valid userId.");
                }
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Close();
        }

        // Event-Handler f�r das Dragging
        private void panelTileBar_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                isDragging = true;
                lastCursor = Cursor.Position;
                lastForm = this.Location;
            }
        }

        private void panelTileBar_MouseMove(object sender, MouseEventArgs e)
        {
            if (isDragging)
            {
                Point delta = Point.Subtract(Cursor.Position, (Size)lastCursor);
                this.Location = Point.Add(lastForm, (Size)delta);
            }
        }

        private void panelTileBar_MouseUp(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                isDragging = false;
            }
        }
    }
}
